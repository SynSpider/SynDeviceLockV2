package com.syn.brick;

import android.app.admin.DeviceAdminReceiver;

public class SynDeviceAdminReceiver extends DeviceAdminReceiver {
    // No code needed — just enabling admin protection
}